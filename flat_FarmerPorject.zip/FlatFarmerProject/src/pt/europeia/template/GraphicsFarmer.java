package pt.europeia.template;

import java.io.File;
import java.util.ArrayList;

import javafx.geometry.VPos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import pt.europeia.graphlib.GraphController;
import javafx.application.Application;



public class GraphicsFarmer extends GraphController {

public File culturesFile = new File("cultures.txt");
public String culturesFileContent;

public int openCulture = 0;
public int context = 0;
public int enviroAssign = 0;
private CultureBar cultureBar;
private MenuButtons editButton;
private MenuButtons cultureButton;
public ArrayList<Environment> environments = new ArrayList<Environment>(0);
public ArrayList<Culture> cultures = new ArrayList<Culture>(0);
public NewCulture newCulture;
public NewCulture editCulture;
public int buttonActive = 0;
public JSONReader jSONReader;
public MenuButtons sugestao;
public MenuButtons backButton;
public SugestionButton sugestoes1;
public SugestionButton sugestoes2;
public SugestionButton sugestoes3;
public SugestionButton sugestoes4;
public SugestionButton sugestoes5;
public SugestionButton [] listaSugestoes ;



	@Override
	protected void start() {
		
		jSONReader = new JSONReader("files/cultures.txt", graphics);
		SugestionButton listasugestoes[]= {sugestoes1,sugestoes2,sugestoes3,sugestoes4,sugestoes5};
		double dummyHumiRange[] = {10, 15};
		double dummyTempRange[] = {10, 30};
		double dummyLumiRange[] = {20, 40};
		double dummyHumiRange2[] = {20, 30};
		double dummyTempRange2[] = {20, 30};
		double dummyLumiRange2[] = {50, 60};
		double dummyHumiRange3[] = {2, 5};
		double dummyTempRange3[] = {2, 5};
		double dummyLumiRange3[] = {2, 5};
		
		environments.add(new Environment("Ambiente1", dummyTempRange, dummyLumiRange, dummyHumiRange));
		environments.add(new Environment("Ambiente2", dummyTempRange2, dummyLumiRange2, dummyHumiRange2));
		environments.add(new Environment("Ambiente3", dummyTempRange3, dummyLumiRange3, dummyHumiRange3));
		cultures = jSONReader.cultureReader(environments);
		editButton = new MenuButtons(graphics, "Edit Culture", 45, 500);
		cultureButton = new MenuButtons(graphics, "New Culture", 500, 500);
		cultureBar = new CultureBar(graphics, cultures);
		newCulture = new NewCulture("New Culture", environments, graphics, "Back");
		editCulture = new NewCulture("Edit Culture", environments, graphics, "Delete");
		//sugestao = new SugestionButton (graphics, "Sugestion",500,580);
	
		sugestao = new MenuButtons (graphics,"Sugestão",500,580);
		backButton = new MenuButtons (graphics,"back",50,580);
		sugestoes1 = new SugestionButton (graphics,"Manjericão", 50, 60,"teste1");
		sugestoes2= new SugestionButton (graphics,"Tomilho", 50, 150,"teste2");
		sugestoes3 = new SugestionButton (graphics,"Ortelã", 50, 240,"teste3");
		sugestoes4 = new SugestionButton (graphics,"Salsa", 50, 340,"teste4");
		sugestoes5 = new SugestionButton (graphics,"Oregãos", 50, 440,"teste5");
		

		jSONReader.cultureSave(cultures);

	}
	
	@Override
	protected void update() {
	}

	
	@Override
	protected void draw() {
		
		cleanScreen();
		
		if(context == 0) {
		
			cultures.get(openCulture).draw();
			cultureBar.draw(openCulture);
			editButton.draw(false, false);
			cultureButton.draw(false, false);
			
		} else if(context == 1) {
			newCulture.draw(buttonActive);
			sugestao.draw(false, true);
			
		} else if(context == 2) {
			editCulture.draw(buttonActive);
			
		} else if(context ==3) {
	
			//sugestao.draw(false, true);
			sugestoes1.draw();
			sugestoes2.draw();
			sugestoes3.draw();
			sugestoes4.draw();
			sugestoes5.draw();
			backButton.draw(false,false);
			
		}
		else if (context==4) {
			backButton.draw(false, false);
		}

}
	
	@Override
	protected void mouseRead(double x, double y) {
			System.out.println("x : " +x + " y = " + y);
			if (context==3) {
				if (x>=53 && x<=196 && y>=583 && y<=647) {
					context=0;
				} else if (x>=59 && x<=195 && x>=64 && x<=122) {
					context =4;
					   
					
				}
			}
            if (context==4) {
            	 if (x>=53 && x<=196 && y>=583 && y<=647) context=3;
            }
			if(context == 0) {
				if(x >= 60 && x <= 200 && y >= 600 && y <= 630) {
					if(cultures.get(openCulture).isIrrig()) {
						cultures.get(openCulture).irrig(false);
					}else 
						cultures.get(openCulture).irrig(true);		
				}else if(x >= 500 && x <= 750 && y >= 500 && y <= 570)
					context = 1;
				else if(x >= 45 && x <= 195 && y >= 500 && y<= 570) {
					context = 2;
					editCulture.setText(cultures.get(openCulture).getName());
					for (int i = 0; i < environments.size(); i++) {
						if(cultures.get(openCulture).getEnvironment().equals(environments.get(i).getName()))
							enviroAssign = i;
					}
				}
				else {
					for(int i = 0; i < cultures.size(); i++) {
						if(x >= 500 && x <= 680 && y >= 80 + i * 20 && y <= 100 + i * 20) 
							openCulture = i;			
				}
				}
			} else if(context == 1 || context ==2) {
				if (context==1) {
					if (x<645 && x>511 && y<646 && y>583) {
						System.out.println("aqui vão aparecer as sugestões");
					    context = 3;}
				}
				if (x >= 500 && x <= 750 && y >= 500 && y <= 570){
					if(newCulture.getText().length() > 0 && context == 1) {
						cultures.add(new Culture(graphics,newCulture.getText(),15, 15, 25, false, environments.get(enviroAssign)));
						jSONReader.cultureSave(cultures);}
					else if(editCulture.getText().length() > 0 && context == 2) {
						System.out.println(editCulture.getText() + enviroAssign);
						cultures.get(openCulture).setEnvironment(environments.get(enviroAssign));
						cultures.get(openCulture).setName(editCulture.getText());
						jSONReader.cultureSave(cultures);
					}
					context = 0;
					enviroAssign = 0;
					newCulture.removeText();
					buttonActive = 0;
				} else if(x >= newCulture.getTEXTBOXPOSX() && x <= newCulture.getTEXTBOXPOSX()+newCulture.getTEXTBOXWIDTH() && y <= newCulture.getTEXTBOXPOSY()+newCulture.getTEXTBOXHEIGHT() && y >= newCulture.getTEXTBOXPOSY()) {
					newCulture.setWritingActive(true);
					System.out.printf("active");
				}else if(x >= 45 && x <= 195 && y >= 500 && y<= 570){
					if(context == 2 && cultures.size() > 1) {
						cultures.remove(openCulture);
						openCulture = 0;
						jSONReader.cultureSave(cultures);
					}
					context = 0;
					enviroAssign = 0;
					newCulture.removeText();
					buttonActive = 0;

				}
				else {
					for(int i = 0; i < newCulture.getButtons().size(); i++) {
						if(x >= newCulture.getButtons().get(i).getXPos() && x <= newCulture.getButtons().get(i).getXPos() + newCulture.getButtons().get(i).getBOXWIDTH() && y >= newCulture.getButtons().get(i).getYPos() && y <= newCulture.getButtons().get(i).getYPos() + newCulture.getButtons().get(i).getBOXHEIGHT()) {
							buttonActive = i;
							enviroAssign = i;
						} 
					} 
				}
			}
				
			
	}

	@Override
	protected void readCommand(KeyCode code) {
		if (context == 0) {
		switch(code) {
			case UP:
				if(openCulture > 0) {
					openCulture --;
				}
				break;
			case W:
				if(openCulture > 0) {
					openCulture --;
				}
				break;
			case DOWN:
				if(openCulture < cultures.size() - 1 ) {
					openCulture ++;
				}
				break;
			case S:
				if(openCulture < cultures.size() - 1 ) {
					openCulture ++;
				}
				break;
			case I:
				if(cultures.get(openCulture).isIrrig()) {
					cultures.get(openCulture).irrig(false);
				}else 
					cultures.get(openCulture).irrig(true);
			}
		} else if(context == 1 || context == 2) {
			if(newCulture.isWritingActive()) {
				switch(code) {
					case ENTER:
						if(context ==1)
							newCulture.setWritingActive(false);
						else
							editCulture.setWritingActive(false);
						break;
					case BACK_SPACE:
						if(context == 1)
							newCulture.removeLetter();
						else
							editCulture.removeLetter();
						break;
					case SPACE:
						if(context == 1)
							newCulture.writeText(" ");
						else
							editCulture.writeText(" ");
						break;
					default:
						if(code.isLetterKey()) {
							if(context == 1)
								newCulture.writeText(code.getName());
							else
								editCulture.writeText(code.getName());
						}
				}
			}else {
				
				}
			}

		}
		
		

	public static void main(String[] args) {
		launch(args);
	}
	
}
