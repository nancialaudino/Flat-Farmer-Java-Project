package pt.europeia.template;

import javafx.geometry.VPos;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import pt.europeia.graphlib.GraphController;

public class Culture {
	private String name; /* nome da cultura, ex: Coentros, Orégão, Alecrim, Camomila, Hortelã, etc. */
	private double temp; /* Temperatura ideal para a cultura */
	private double humidity; /* Humidade ideal para a planta */
	private double lumi; /* luminosidade ideal em que a cultura pode estar exposta */
	private boolean irrig; /* Devolve True se tiver que irrigar, e False caso contrário */
	private static int MAINBOXWIDTH = 100;
	private static int MAINBOXHEIGHT = 50;
	private static int INFOSQUAREDIMENTION = 30;
	private static int BASEYPOSITION = 80;
	private static int BASEXPOSITION = 50;
	private static int YVARIATION = 100;
	private Environment environment;
	private GraphicsContext graphics;

	/** Este é o costrutor principal da Classe Culture */
	
    public Culture (GraphicsContext graphics, String name, double humidity,double temp, double lumi, boolean isIrrig, Environment environment) {
	 this.graphics = graphics;
     this.name = name;
	 this.temp = temp;
	 this.environment = environment;
	 this.humidity = humidity;
	 this.lumi = lumi;
	 this.irrig = isIrrig;
    }
    /** Método utilizado para desenhar cada rétangulo de monitorização */
    // box 0 = humidade, 1 = temperatura, 2 = luminosidade
 private String setAlertSquare(int box, double value, double valueLimits[]) {
	 graphics.setFill(Color.BLACK);
	 graphics.strokeRoundRect(BASEXPOSITION, BASEYPOSITION + box * YVARIATION, MAINBOXWIDTH, MAINBOXHEIGHT, 10, 10);
	 
	 String responses[] = {"- Humidity","- Temperature", "- Luminosity","- Humidity, water your culture", "- Temperature, move your culture to a warmer area", "-Luminosity, move your culture to a lighter area", "- Humidity, culture overwatered", "- Temperature, move culture to cooler area", "-Luminosity, move your culture to a darker area" };
	 
	 if(value >= valueLimits[0]&&value <= valueLimits[1]) {
			graphics.setFill(Color.DARKGREEN);
			graphics.fillRoundRect(BASEXPOSITION, BASEYPOSITION + box * YVARIATION, MAINBOXWIDTH, MAINBOXHEIGHT, 10, 10);
			
			return responses[box];
			
		} else if(value < valueLimits[0] && value >= valueLimits[0]/2 || value > valueLimits[1] && value <= valueLimits[1] + valueLimits[0]/2) {
			graphics.setFill(Color.DARKORANGE);
			graphics.fillRoundRect(BASEXPOSITION, BASEYPOSITION + box * YVARIATION, MAINBOXWIDTH, MAINBOXHEIGHT, 10, 10);
			
			if(value < valueLimits[0]) {
				
				return responses[box + 3];
				
			} else {
				
				return responses[box + 6];
				
				
			}
		} else {
			graphics.setFill(Color.DARKRED);
			graphics.fillRoundRect(BASEXPOSITION, BASEYPOSITION + box * YVARIATION, MAINBOXWIDTH, MAINBOXHEIGHT, 10, 10);
			
			if(value < valueLimits[0]) {
				
				return responses[box + 3] + "!";
				
			} else {
				
				return responses[box + 6] + "!";
				
			}
		}
 }
 public void draw() {
	 
	graphics.setFill(Color.BLACK);
	graphics.setFont(new Font(15));
	graphics.setStroke(Color.BLACK);
	
	String stableLabel = "- Stable";
	String warningLabel = "- Warning";
	String criticalLabel = "- Critical";
	String toggleLabel = "Auto Irrigation";
	// escolhe o label de cada retangulo e desanha-lo
	String humidityLabel = setAlertSquare(0, humidity, environment.getHumiData());
	String temperatureLabel = setAlertSquare(1, temp, environment.getTempData());
	String luminosityLabel = setAlertSquare(2, lumi, environment.getLumiData());
	
	if (irrig)
		graphics.setFill(Color.DARKGREEN);
	else
		graphics.setFill(Color.DARKRED);
	
	graphics.fillOval(60, 600, INFOSQUAREDIMENTION, INFOSQUAREDIMENTION); //irrigation toggle
	graphics.setFill(Color.DARKGREEN);
	graphics.fillRoundRect(300, 600, INFOSQUAREDIMENTION, INFOSQUAREDIMENTION, 10, 10);// stable rectangle
	graphics.setFill(Color.DARKORANGE);
	graphics.fillRoundRect(400, 600, INFOSQUAREDIMENTION, INFOSQUAREDIMENTION, 10, 10);// warning rectangle
	graphics.setFill(Color.DARKRED);
	graphics.fillRoundRect(520, 600, INFOSQUAREDIMENTION, INFOSQUAREDIMENTION, 10, 10);// critical Rectangle 

	graphics.getTextAlign();

	graphics.setFill(Color.BLACK);
	graphics.fillText(name, 70, 60); 
	graphics.fillText(stableLabel, 330, 620);
	graphics.fillText(warningLabel, 430, 620); 
	graphics.fillText(criticalLabel, 550, 620); 
	graphics.fillText(toggleLabel, 100, 620); 
	graphics.fillText(humidityLabel, 160, 110); 
	graphics.fillText(temperatureLabel, 160, 210);
	graphics.fillText(luminosityLabel, 160, 310);
}


//Metodos Getter e Setters
	
public String getEnvironment() {
	return environment.getName();
	
}

public String getName () {
	return name;
	
}

public double getTemp () {
	return temp;
	
}

public double getHumidity () {
	return humidity;
	
}

public double getLumi () {
	return lumi;
}
	

public boolean isIrrig () {
	return irrig ;
	
}


public void setName(String name) {
	this.name = name;
}

public void setEnvironment (Environment environment) {
	  this.environment = environment;
		
}

public void setTemp (double temp) {
	 this.temp = temp;
	
}


public void setHumidity (double humidity) {
	   this.humidity = humidity;
	
}


public void setLumi (double lumi ) {
	   this.lumi = lumi;
	
}

public int getStatus () {
	if(temp < environment.getTempData()[0]/2 || temp > environment.getTempData()[1]+environment.getTempData()[0]/2 || humidity < environment.getHumiData()[0]/2 || humidity > environment.getHumiData()[1]+environment.getHumiData()[0]/2 ||lumi < environment.getLumiData()[0]/2 || lumi > environment.getLumiData()[1]+environment.getLumiData()[0]/2 )
		return 2;
	else if(temp < environment.getTempData()[0] || temp > environment.getTempData()[1] || humidity < environment.getHumiData()[0] || humidity > environment.getHumiData()[1] || lumi < environment.getLumiData()[0] || lumi > environment.getLumiData()[1]) 
		return 1;
	else
		return 0;
}


/* !usei o is porque para atributos boolean os setters não funcionam (??)(precisa-se confirmar) */

public void irrig(boolean isIrrig) {
	   this.irrig = isIrrig;
	
}
}

