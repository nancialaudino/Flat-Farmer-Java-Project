package pt.europeia.template;
import javafx.geometry.VPos;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import pt.europeia.graphlib.GraphController;

public class MenuButtons extends GraphController {
	private String title;
	public double xPos;
	public double yPos;
	public static double BOXHEIGHT = 70;
	public static double BOXWIDTH = 150;
	private static double TEXTYOFFSET = 38;
	private static double TEXTXOFFSET = 15;
	private GraphicsContext graphics;
	

	//Construtor principal da classe MenuButtons
	public MenuButtons (GraphicsContext graphics, String title, double xPos, double yPos){
		this.graphics = graphics;
		this.title = title;
		this.xPos = xPos;
		this.yPos = yPos;
		
	}
	//@Override
	public double getXPos() {
		return xPos;
	}
	
	public double getYPos() {
		return yPos;
	}
	public double getBOXHEIGHT() {
		return BOXHEIGHT;
	}
	public double getBOXWIDTH() {
		return BOXWIDTH;
	}
	
	
	public void draw(boolean active, boolean yellow) {
		if (active)
			graphics.setFill(Color.GREY);
		else if (yellow)
			graphics.setFill(Color.YELLOW);
		else
			graphics.setFill(Color.LIGHTGREY);
			
			graphics.setFont(new Font("Arial Bold",14)); //tipo de letra e tamanho
			
			
			graphics.fillRoundRect(xPos, yPos, BOXWIDTH, BOXHEIGHT, 30, 30);// menu rectangle
			graphics.setFill(Color.BLACK);
			graphics.fillText(title, xPos + TEXTXOFFSET, yPos + TEXTYOFFSET);
	}
}





