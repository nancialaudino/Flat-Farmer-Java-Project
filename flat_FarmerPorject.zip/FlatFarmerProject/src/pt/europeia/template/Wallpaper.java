package pt.europeia.template;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Wallpaper extends Application {

 private final String IMG_URL = "http://vozdocampo.pt/wp-content/uploads/2017/09/Vitracress-810x446.jpg";
 private GraphicsContext graphics;
 
 

// throws vai à assinatura do método e indica que este método poderá lançar uma exceção que deve ou ser relançada ou capturada pelo método que a está a chamar
 
 @Override
 public void start (Stage palco) throws Exception {
  Image imagem = new Image(IMG_URL); // 1
  ImageView visualizadorImagem = new ImageView(imagem); // 2
  visualizadorImagem.setTranslateX(100); // 3
  visualizadorImagem.setTranslateY(30); // 4

  Group componentes = new Group(); // 9
  componentes.getChildren().addAll(visualizadorImagem);
  Scene cena = new Scene(componentes, 5020, 500);
  palco.setTitle("Gráficos e Imagens em JavaFX");
  palco.setScene(cena);
  palco.show();
 }
}