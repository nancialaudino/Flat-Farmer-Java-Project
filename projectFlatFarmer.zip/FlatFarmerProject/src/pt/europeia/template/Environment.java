package pt.europeia.template;

public class Environment {
	public String name;
	public double[] tempData;
	public double[] lumiData;
	public double[] humiData;
	
	public Environment(String name, double[] tempData, double[] lumiData, double[] humiData){
		this.name = name;
		this.tempData = tempData;
		this.lumiData = lumiData;
		this.humiData = humiData;
	}

	public String getName() {
		return name;
	}

	public double[] getTempData() {
		return tempData;
	}

	public double[] getLumiData() {
		return lumiData;
	}

	public double[] getHumiData() {
		return humiData;
	}
}
