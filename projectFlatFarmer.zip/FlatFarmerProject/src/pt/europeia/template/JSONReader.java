package pt.europeia.template;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javafx.scene.canvas.GraphicsContext;


public class JSONReader {
	private String cultureDirectory;
	private GraphicsContext graphics;
	
	JSONReader(String cultureDirectory, GraphicsContext graphics){
		this.cultureDirectory = cultureDirectory;
		this.graphics = graphics;
	}
	
	public void cultureSave(ArrayList<Culture> cultures){
		JSONArray jSONArray = new JSONArray();
		try {
			
			for(int i = 0; i < cultures.size(); i++) {
				JSONObject cultureJSON = new JSONObject();
				cultureJSON.put("environment", cultures.get(i).getEnvironment());
				cultureJSON.put("name",cultures.get(i).getName());
				cultureJSON.put("irrig", cultures.get(i).isIrrig());
				jSONArray.put(cultureJSON);
			}
		} catch (JSONException e) {
			System.out.println(e);
		}
		try {
			FileWriter fileWriter = new FileWriter(cultureDirectory);
			fileWriter.write(jSONArray.toString());
			fileWriter.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	public ArrayList<Culture> cultureReader(ArrayList<Environment> environments){
	 	JSONArray cultureArray= null;
		JSONObject iteration;
		Environment environment = null;
		ArrayList<Culture> cultures = new ArrayList<Culture>(0);
		try {
			cultureArray= new JSONArray(new String(Files.readAllBytes(Paths.get(cultureDirectory))));
				for(int i = 0; i < cultureArray.length(); i++) {
					iteration = cultureArray.getJSONObject(i);
					for(int f = 0; f < environments.size(); f++) {

						if(iteration.getString("environment").equals(environments.get(f).getName())) 
							environment = environments.get(f);
						
					}
					cultures.add(new Culture(graphics, iteration.getString("name"), 15, 15, 25, iteration.getBoolean("irrig"), environment));
				}
			}
		catch (JSONException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
		return cultures;

	}
	
}
