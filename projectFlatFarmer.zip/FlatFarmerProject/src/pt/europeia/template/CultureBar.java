package pt.europeia.template;

import java.util.ArrayList;

import javafx.geometry.VPos;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import pt.europeia.graphlib.GraphController;

public class CultureBar {
	// will add x and y coordinates here
	private static int BARPOSITIONX = 500;
	private static int BARPOSITIONY = 80;
	private static int BARWIDTH = 180;
	public static int BARHEIGHT = 20;
	public static int TEXTYOFFSET = 15;
	public static int TEXTXOFFSET = 5;
	private GraphicsContext graphics;
	private ArrayList<Culture> cultures;
	
	CultureBar (GraphicsContext graph, ArrayList<Culture> cultures){
		this.graphics = graph;
		this.cultures = cultures;
	}
	
	public void draw(int openContext) {
		String name = "";
		for(int i = 0; i < cultures.size(); i++) {
			name = cultures.get(i).getName();
			if (openContext == i) {
				graphics.setFill(Color.GREY);
			}
			else {
				switch (cultures.get(i).getStatus()) {
				case 1: graphics.setFill(Color.ORANGE);
				break;
				case 2: graphics.setFill(Color.RED);
				break;
				default: if(i%2 == 1) 
					graphics.setFill(Color.LIGHTGRAY);
				else
					graphics.setFill(Color.WHITE);				
			}
				

			}
			graphics.fillRect(BARPOSITIONX, BARPOSITIONY + BARHEIGHT * i, BARWIDTH, BARHEIGHT);
			graphics.setFill(Color.BLACK);
			graphics.fillText(name, BARPOSITIONX+TEXTXOFFSET, BARPOSITIONY + BARHEIGHT * i + TEXTYOFFSET);
		}

		graphics.strokeRect(BARPOSITIONX, BARPOSITIONY, BARWIDTH, cultures.size() * BARHEIGHT);


	}

}
