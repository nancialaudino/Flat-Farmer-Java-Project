package pt.europeia.template;

import java.util.ArrayList;

import javafx.geometry.VPos;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import pt.europeia.graphlib.GraphController;

public class NewCulture {
	private String title = "New Culture";
	private ArrayList<Environment> environments;
	private GraphicsContext graphics;
	public ArrayList<MenuButtons> buttons = new ArrayList(0);
	private static int ROWSIZE = 4;
	private static double BUTTONXPOS = 50;
	private static double BUTTONYPOS = 150;
	private static double BUTTONXVAR = 200;
	private static double BUTTONYVAR = 150;
	private static MenuButtons DONEBUTTON; 
	private  MenuButtons backButton;
	public static double TEXTBOXPOSX = 50;
	public static double TEXTBOXPOSY = 120;
	public static double TEXTBOXHEIGHT = 20;
	public static double TEXTBOXWIDTH = 360;
	private static double TITLEPOSX = 50;
	private static double TITLEPOSY = 100;
	private static double TEXTYOFFSET = 14;
	private static double TEXTXOFFSET = 15;
	private String text = "";
	public int activeEnvironment = 0;
	public boolean writingActive = false;
	
	
	
	NewCulture (String title, ArrayList<Environment> environments, GraphicsContext graphics, String backOrDelete){
		this.title = title;
		this.environments = environments;
		this.graphics = graphics;
		for(int i = 0; i < environments.size(); i++) {
			buttons.add(new MenuButtons(graphics, environments.get(i).getName(), BUTTONXPOS + i * BUTTONXVAR, BUTTONYPOS + Math.floor(i/4)*BUTTONYVAR));
		}
		DONEBUTTON = new MenuButtons(graphics, "Done", 500, 500);
		backButton = new MenuButtons(graphics, backOrDelete, 45, 500);
	}
	
	public ArrayList<MenuButtons> getButtons(){
		return buttons;
	}
	
	public boolean isWritingActive() {
		return writingActive;
	}
	
	public double getTEXTBOXPOSX() {
		return TEXTBOXPOSX;
	}
	
	public double getTEXTBOXPOSY() {
		return TEXTBOXPOSY;
	}
	
	public double getTEXTBOXHEIGHT() {
		return TEXTBOXHEIGHT;
	}
	
	public double getTEXTBOXWIDTH() {
		return TEXTBOXWIDTH;
	}
	
	public void setWritingActive(boolean writingActive) {
		this.writingActive = writingActive;
	}
	
	
	public void writeText(String letter) {
		text = text + letter;
		text = text.substring(0, 1) + text.substring(1).toLowerCase();
		System.out.printf(letter);
	}
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	public void removeText() {
		text = "";
	}
	
	public void removeLetter() {
		if(text.length() > 0) {
			text = text.substring(0, text.length() - 1);
		}
	}
	
	public void draw(int active) {
		graphics.setFill(Color.BLACK);
		graphics.setFont(new Font("Arial Bold", 24));
		graphics.fillText(title, TITLEPOSX, TITLEPOSY);
		graphics.setFont(new Font("Arial Bold", 12));
		graphics.strokeRect(TEXTBOXPOSX, TEXTBOXPOSY, TEXTBOXWIDTH, TEXTBOXHEIGHT);
		graphics.fillText(text, TEXTBOXPOSX + TEXTXOFFSET, TEXTBOXPOSY + TEXTYOFFSET);
		for(int i = 0; i < environments.size(); i++) {
			if( i == active) 
				buttons.get(i).draw(true, false);
			else
				buttons.get(i).draw(false, false);
		}
		DONEBUTTON.draw(false, false);
		backButton.draw(false, false);
	}
	
}


