package pt.europeia.template;
import javafx.application.Application;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import pt.europeia.graphlib.GraphController;


public class SugestionButton extends Application {
	private String title;
	public double xPos;
	public double yPos;
	public static double BOXHEIGHT = 70;
	public static double BOXWIDTH = 150;
	private static double TEXTYOFFSET = 38;
	private static double TEXTXOFFSET = 15;
	private GraphicsContext graphics;
	private final String IMG_URL = "http://vozdocampo.pt/wp-content/uploads/2017/09/Vitracress-810x446.jpg";
	 
	 
	 

	
	
	//Construtor principal da classe MenuButtons
		public SugestionButton (GraphicsContext graphics, String title, double xPos, double yPos){
			this.graphics = graphics;
			this.title = title;
			this.xPos = xPos;
			this.yPos = yPos;
			
			
		}
		
		//@Override
		public double getXPos() {
			return xPos;
		}
		
		public double getYPos() {
			return yPos;
		}
		public double getBOXHEIGHT() {
			return BOXHEIGHT;
		}
		public double getBOXWIDTH() {
			return BOXWIDTH;
		}
		
		
		
		
		public void draw() {
				graphics.setFill(Color.LIGHTGREEN);
				graphics.setFont(new Font("Arial Bold",15)); //tipo de letra e tamanho
				graphics.fillRoundRect(xPos, yPos, BOXWIDTH, BOXHEIGHT, 30, 30);// menu rectangle
				graphics.setFill(Color.BLACK);
				graphics.fillText(title, xPos + TEXTXOFFSET, yPos + TEXTYOFFSET);
		}

		@Override
		public void start(Stage primaryStage) throws Exception {
			// TODO Auto-generated method stub
			
		}
		
		
		/*
		 
		 public void start (Stage img) throws Exception {
		  Image img = new Image(IMG_URL); // 1
		  ImageView visualizadorImagem = new ImageView(ima); // 2
		  visualizadorImagem.setTranslateX(100); // 3
		  visualizadorImagem.setTranslateY(30); //  4
		  //palco.show();
		 }
	
*/
}



/*

if(context == 1) {
	if (x>=51 && y>=500 && x<=191 && y<=570) {
		System.out.printf("aqui vai aparecer a lista de sugestões");
		 context=3;
		 sugestionbutton.draw();
		 


*/